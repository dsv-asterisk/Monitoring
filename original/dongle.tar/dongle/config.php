<?php

require_once('./phpagi/phpagi_asmanager.php');

$manager_host = '127.0.0.1';	        // IP DO SERVIDOR ASTERISK
$manager_user = 'admin' ;		// USUARIO MANAGER.CONF
$manager_pass = 'amp111';		// SENHA MANAGER.CONF

?>
